// main.js
import * as Storage from './storage.js';
import * as UI from './ui.js';
// เพิ่ม QUIZ_REWARD และดึง todayKey/canAttemptQuiz มาใช้สำหรับ AI Quiz
import { GROWTH_THRESHOLDS, WATER_COST, WATER_GAIN, FERT_COST, FERT_GAIN, DAILY_LIMIT, QUIZ_REWARD } from './config.js'; 
import { todayKey, canAttemptQuiz } from './quiz.js'; 

/* ------------------ Global State ------------------ */
let users = Storage.loadUsers(); // Users database
let current = null; // current user object

// 💡 Global State สำหรับ AI Quiz ต่อเนื่อง
let aiQuizQueue = []; // คิวของคำถาม AI Quiz ที่ Parse แล้ว
let isGenerating = false; // สถานะกำลังสร้างคำถามจาก AI
let isStopped = false; // สถานะผู้ใช้กดหยุด
let aiTopic = ''; // หัวข้อที่ใช้สร้าง Quiz
let aiCountTotal = 0; // จำนวนคำถามทั้งหมดที่ต้องการ
let aiCountAnswered = 0; // จำนวนคำถามที่ตอบไปแล้วในชุดนี้

/* ------------------ DOM Elements ------------------ */
const elements = {
  // Tree & Controls
  treeStageEl: document.getElementById('treeStage'),
  growthBar: document.getElementById('growthBar'),
  growthText: document.getElementById('growthText'),
  coinDisplay: document.getElementById('coinDisplay'),
  attemptInfo: document.getElementById('attemptInfo'),
  logList: document.getElementById('logList'),
  stats: document.getElementById('stats'),
  stageLabel: document.getElementById('stageLabel'),
  gameStatusArea: document.getElementById('gameStatusArea'),
  completeArea: document.getElementById('completeArea'),

  waterBtn: document.getElementById('waterBtn'),
  fertBtn: document.getElementById('fertBtn'),
  quizOpenBtn: document.getElementById('quizOpenBtn'),
  resetBtn: document.getElementById('resetBtn'), // 💡 NEW: เพิ่มปุ่ม Reset

  // Auth
  usernameInput: document.getElementById('usernameInput'),
  passwordInput: document.getElementById('passwordInput'),
  signupBtn: document.getElementById('signupBtn'),
  loginBtn: document.getElementById('loginBtn'),
  logoutBtn: document.getElementById('logoutBtn'),
  authRow: document.getElementById('authRow'),
  logoutRow: document.getElementById('logoutRow'),
  userLabel: document.getElementById('userLabel'),

  // Quiz
  quizContent: document.getElementById('quizContent'),
  quizStopBtn: document.getElementById('quizStopBtn'), 
  quizAiStatus: document.getElementById('quizAiStatus'), 
};

/* ------------------ Core Logic Functions ------------------ */

// Getter สำหรับ Current User
function getCurrent() { return current; }

// บันทึก User ปัจจุบันไป LocalStorage
function saveCurrent() {
  if (!current) return;
  users = Storage.loadUsers();
  users[current.username] = current;
  Storage.saveUsers(users);
}

// เพิ่ม Log
function addLog(text) {
  if (!current) return;
  const ts = new Date().toLocaleString();
  current.logs.unshift(`[${ts}] ${text}`);
  if (current.logs.length > 200) current.logs.length = 200;
}

// ฟังก์ชันสำหรับเมื่อต้นไม้โตเต็มที่
function onComplete() {
  addLog('ต้นไม้โตเต็มที่ — จบเกม');
  saveCurrent();
  UI.updateUI(current);
}

// 💡 NEW: จัดการการรีเซ็ตต้นไม้
function handleReset() {
  if (!current) return alert('กรุณา login ก่อน');
  
  if (current.growth >= 100) {
    // 💡 ตั้งค่า growth กลับไปที่ 0
    current.growth = 0; 
    addLog(`🌱 รีเซ็ตต้นไม้! เริ่มปลูกใหม่!`);
    saveCurrent();
    UI.updateUI(current);
  } else {
    // เพิ่มการแจ้งเตือน หากพยายามรีเซ็ตก่อนโตเต็มที่
    addLog(`⛔ ต้นไม้ยังโตไม่เต็มที่ (ต้อง 100%)`, 'error');
    alert('ต้นไม้ยังโตไม่เต็มที่ (ต้อง 100%)');
  }
}


/* ------------------ Auth Logic ------------------ */
function loginLocal(username, password) {
  users = Storage.loadUsers();
  if (!users[username]) return { ok: false, msg: "ไม่พบผู้ใช้" };
  if (users[username].password !== btoa(password || '')) return { ok: false, msg: "รหัสไม่ถูกต้อง" };

  Storage.setSession(username);
  current = users[username];
  UI.uiAfterLogin(username);
  addLog("เข้าสู่ระบบ");
  saveCurrent();
  UI.updateUI(current);
  return { ok: true };
}

function signupLocal(username, password) {
  users = Storage.loadUsers();
  if (!username || !password) return { ok: false, msg: "กรอก username/password" };
  if (users[username]) return { ok: false, msg: "มีผู้ใช้นี้แล้ว" };

  users[username] = Storage.createUserObj(username, password);
  Storage.saveUsers(users);

  Storage.setSession(username);
  current = users[username];
  UI.uiAfterLogin(username);
  addLog("สมัครและเข้าสู่ระบบ");
  saveCurrent();
  UI.updateUI(current);
  return { ok: true };
}

function handleSignup() {
  const u = elements.usernameInput.value.trim();
  const p = elements.passwordInput.value;
  const r = signupLocal(u, p);
  if (!r.ok) alert(r.msg);
  elements.usernameInput.value = '';
  elements.passwordInput.value = '';
}

function handleLogin() {
  const u = elements.usernameInput.value.trim();
  const p = elements.passwordInput.value;
  const r = loginLocal(u, p);
  if (!r.ok) alert(r.msg);
  elements.usernameInput.value = '';
  elements.passwordInput.value = '';
}

function handleLogout() {
  if (current) addLog("ออกจากระบบ");
  current = null;
  Storage.clearSession();
  UI.uiAfterLogout();
  UI.updateUI(current);
}

/* ------------------ Game Control ------------------ */

function applyGrowth(delta, source) {
  if (!current || current.growth >= 100) return;
  const old = current.growth;
  current.growth = Math.min(100, current.growth + delta);
  saveCurrent();
  addLog(`${source}: +${delta}% (จาก ${Math.round(old)} → ${Math.round(current.growth)}%)`);
  UI.updateUI(current);
  if (current.growth >= 100) onComplete();
}

function handleWater() {
  if (!current) return alert('กรุณา login ก่อน');
  if (current.coins < WATER_COST) return alert('เหรียญไม่พอ');
  current.coins -= WATER_COST;
  applyGrowth(WATER_GAIN, 'รดน้ำ');
}

function handleFert() {
  if (!current) return alert('กรุณา login ก่อน');
  if (current.coins < FERT_COST) return alert('เหรียญไม่พอ');
  current.coins -= FERT_COST;
  applyGrowth(FERT_GAIN, 'ปุ๋ย');
}


/* ------------------ AI Quiz Integration (Refactored) ------------------ */

// ฟังก์ชันเริ่มต้นการสร้าง Quiz (กดปุ่ม ❓)
async function startAIQuizGeneration() {
  if (!current) return alert('กรุณา login ก่อน');
  if (isGenerating) return; 

  if (!canAttemptQuiz(current)) return alert(`คุณตอบครบ ${DAILY_LIMIT} ครั้งสำหรับวันนี้แล้ว 😊`);

  const topic = prompt("พิมพ์หัวข้อที่ต้องการให้ AI สร้างคำถาม:", aiTopic || "สิ่งแวดล้อม");
  if (!topic) return;
  const countInput = prompt("จำนวนคำถามที่ต้องการ (สูงสุด 10 ข้อ):", aiCountTotal > 0 ? aiCountTotal : 3);
  const count = parseInt(countInput) || 1;
  if (count <= 0 || count > 10) return alert('กรุณากรอกจำนวนคำถามระหว่าง 1 ถึง 10');

  // 💡 รีเซ็ต Global State
  aiTopic = topic;
  aiCountTotal = count;
  aiCountAnswered = 0;
  aiQuizQueue = [];
  isStopped = false;
  isGenerating = true;

  elements.quizOpenBtn.disabled = true;
  elements.quizStopBtn.style.display = 'inline-block';
  elements.quizAiStatus.style.display = 'inline-block';
  elements.quizContent.innerHTML = "⏳ กำลังสร้างคำถาม...";

  // --- 🚀 การปรับปรุง: Cache Busting และ Prompt Hint ที่เข้มงวดสูงสุด ---
  const nonce = `${Date.now()}-${Math.floor(Math.random()*1e9)}`; 

  // NEW: ใช้ Cachebuster ใน URL เพื่อหลีกเลี่ยงการแคชทุกระดับ
  const apiUrl = `/api/quiz?cachebuster=${nonce}`; 

  const payload = { 
    topic, 
    count,
    // NEW: รวม nonce เข้าใน body และใช้คำสั่งที่เข้มงวดที่สุด
    nonce: nonce,
    prompt_hint: `Generate ${count} UNRELATED and CONCEPTUALLY DIVERSE multiple-choice questions on "${topic}". **Each question MUST cover a completely UNIQUE core fact or sub-topic.** Do not paraphrase, rephrase, or reuse the same underlying principle/answer/scenario. MAXIMIZE variety in every single question.`
  };
  
  try {
    const res = await fetch(apiUrl, { 
      method: "POST",
      // NEW: Cache Control ที่เข้มงวดที่สุดใน Header
      headers: { 
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
      },
      body: JSON.stringify(payload)
    });
    
    const data = await res.json();
    const quizText = data.quiz || "❌ ไม่สามารถสร้างคำถามได้";
    
    if (!res.ok) {
        elements.quizContent.innerHTML = `<p style="color:red;">❌ **API Error**</p><p>เกิดข้อผิดพลาดในการเรียก API: ${data.quiz || 'ไม่ระบุ'}</p>`;
        return;
    }
    
    aiQuizQueue = parseAIQuiz(quizText);
    
    // 💡 FIX: ปรับ aiCountTotal ให้เป็นจำนวนคำถามที่ Parse ได้จริง
    if (aiQuizQueue.length > 0 && aiQuizQueue.length !== aiCountTotal) {
      aiCountTotal = aiQuizQueue.length;
      addLog(`ปรับจำนวนคำถามเป็น ${aiCountTotal} เนื่องจาก AI ตอบมาไม่ครบ`);
    }

    if (aiQuizQueue.length === 0) {
        elements.quizContent.innerHTML = `<p style="color:red;">❌ **Parsing Failed**</p><p>AI ไม่ได้ตอบตามรูปแบบที่กำหนด</p><pre style="white-space:pre-wrap; max-height:100px; overflow-y:auto;">${escapeHtml(quizText)}</pre>`;
        return; 
    }

  } catch (err) {
    elements.quizContent.innerHTML = `<p style="color:red;">❌ **Connection Error**</p><p>เกิดข้อผิดพลาดในการเชื่อมต่อ: ${escapeHtml(err.message)}</p>`;
  } finally {
    isGenerating = false;
    
    if (!isStopped) {
        if (aiQuizQueue.length > 0) {
            nextAIQuestion();
        } else {
            resetAIQuizState(); // หากคิวว่างเนื่องจาก Error ให้รีเซ็ตสถานะ
        }
    } else {
        resetAIQuizState();
    }
  }
}

// ฟังก์ชันสำหรับแสดงคำถามถัดไป
function nextAIQuestion() {
    if (isStopped || aiQuizQueue.length === 0) {
        resetAIQuizState();
        return;
    }

    if (!canAttemptQuiz(current)) {
        alert(`คุณตอบครบ ${DAILY_LIMIT} ครั้งสำหรับวันนี้แล้ว 😊`);
        resetAIQuizState();
        return;
    }

    const qObj = aiQuizQueue.shift();
    aiCountAnswered++;
    // 💡 ใช้ aiCountTotal ที่ปรับปรุงแล้ว
    elements.quizAiStatus.innerText = `หัวข้อ: ${aiTopic} | คำถามที่: ${aiCountAnswered}/${aiCountTotal}`;
    showAIQuestion(qObj, current, elements.quizContent);
}

// Parser ข้อความ AI Quiz ให้ออกเป็น Array ของ { question, choices:[], answerIndex }
function parseAIQuiz(text) {
  const quizItems = text.split('---QUIZ-ITEM---').map(s => s.trim()).filter(s => s);
  const parsedQuizzes = [];

  quizItems.forEach((item, index) => {
    try {
      const lines = item.split('\n').map(l=>l.trim()).filter(l=>l);
      
      const questionLine = lines.find(l => l.match(/^(?:\d+\.\s*)?(?:คำถาม|Q|คำถามที่ \d+)\s*:/i));
      if (!questionLine) return;

      const choices = lines.filter(l => /^[a-cA-C]\./.test(l)).map(l => l.replace(/^[a-cA-C]\./, '').trim()); 
      
      const answerLine = lines.find(l => l.match(/^คำตอบที่ถูก\s*:/));
      
      if (choices.length !== 3 || !answerLine) return;
      
      const qMatch = questionLine.match(/^(?:\d+\.\s*)?(?:คำถาม|Q|คำถามที่ \d+)\s*:\s*(.*)/i);
      const question = qMatch ? qMatch[1].trim() : questionLine.trim();

      const answerMatch = answerLine.match(/คำตอบที่ถูก:\s*([A-C])/i);
      if (!answerMatch) return; 
      
      const answerChar = answerMatch[1].toUpperCase();
      const answerIndex = ['A','B','C'].indexOf(answerChar);
      
      if (answerIndex === -1) return; 
      
      parsedQuizzes.push({ question, choices, answerIndex });
    } catch(e) { console.error("parseAIQuiz error for item", index + 1, e); }
  });

  return parsedQuizzes;
}

// แสดง Quiz AI แบบมีปุ่มตัวเลือก
function showAIQuestion(qObj, current, container) {
  container.innerHTML = '';
  
  const elQ = document.createElement('div');
  elQ.innerHTML = `<div style="font-weight:700">${escapeHtml(qObj.question)}</div><div class="muted" style="margin-top:6px">เลือกคำตอบ</div>`;

  const choicesWrap = document.createElement('div');
  choicesWrap.className = 'choices';

  if (!qObj.choices || !Array.isArray(qObj.choices)) {
    container.innerHTML = `<p style="color:red;">❌ คำถามนี้ไม่มีตัวเลือกที่สมบูรณ์</p>`;
    return;
  }

  qObj.choices.forEach((c, i) => {
    const btn = document.createElement('button');
    btn.className = 'choice-btn';
    btn.innerText = c;
    btn.addEventListener('click', () => handleAIAnswer(btn, i === qObj.answerIndex, qObj, current, container));
    choicesWrap.appendChild(btn);
  });

  container.appendChild(elQ);
  container.appendChild(choicesWrap);
}

// จัดการเมื่อผู้ใช้เลือกคำตอบ AI Quiz
function handleAIAnswer(btn, correct, qObj, current, container) {
  const btns = container.querySelectorAll('.choice-btn');
  // ปิดการใช้งานปุ่มทั้งหมดหลังเลือก
  btns.forEach(b => b.disabled = true);

  // อัปเดตการนับ Quiz
  current.quizCountToday = (current.quizCountToday || 0) + 1;
  current.lastQuizDate = todayKey(); 

  let quizReward = 0;
  if (correct) {
    quizReward = QUIZ_REWARD;
    current.coins = (current.coins || 0) + quizReward; 
    addLog(`ตอบ AI Quiz ถูก (Q${aiCountAnswered}): +${quizReward} coin`);
    btn.classList.add('correct');
  } else {
    addLog(`ตอบ AI Quiz ผิด (Q${aiCountAnswered})`);
    btn.classList.add('wrong');
    // ไฮไลท์คำตอบที่ถูก
    if (btns[qObj.answerIndex]) {
      btns[qObj.answerIndex].classList.add('correct');
    }
  }

  saveCurrent();
  UI.updateUI(current); 
  
  // Auto-Generate: โหลดคำถามถัดไปหลังจากหน่วงเวลาสั้นๆ
  setTimeout(() => {
    if (isStopped) {
        resetAIQuizState();
    } 
    else if (aiQuizQueue.length === 0) { 
        // ใช้ aiCountTotal ที่ปรับปรุงแล้ว
        alert(`🎉 ตอบครบ ${aiCountTotal} ข้อแล้ว!`); 
        resetAIQuizState();
    }
    else {
        nextAIQuestion();
    }
  }, 1500); // หน่วงเวลา 1.5 วินาที
}

// ฟังก์ชันหยุดการสร้าง Quiz
function stopAIQuizGeneration() {
    isStopped = true;
    resetAIQuizState();
}

// ฟังก์ชันรีเซ็ตสถานะ AI Quiz
function resetAIQuizState() {
    aiQuizQueue = [];
    isGenerating = false;
    isStopped = false;
    aiCountAnswered = 0;
    aiCountTotal = 0; 

    // อัปเดต UI ที่เกี่ยวข้องกับการโหลด
    elements.quizStopBtn.style.display = 'none';
    elements.quizAiStatus.style.display = 'none';
    elements.quizAiStatus.innerText = '';
    
    // คืนค่า UI
    elements.quizContent.innerHTML = `<div class="muted">กด "ตอบคำถาม" เพื่อเริ่ม</div>`;
    
    UI.updateUI(current); 
    
    if (current) saveCurrent(); 
}

/* ------------------ Utility ------------------ */
function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[c]);
}


/* ------------------ Initialization ------------------ */

// ผูก Event Listener สำหรับ Quiz
elements.quizOpenBtn.addEventListener('click', startAIQuizGeneration);
elements.quizStopBtn.addEventListener('click', stopAIQuizGeneration);


UI.initUI(elements, { 
    getCurrent, 
    addLog, 
    saveCurrent, 
    onComplete,
    handleWater, 
    handleFert,
    handleReset, // 💡 NEW: ส่ง handleReset
    handleSignup, 
    handleLogin, 
    handleLogout 
});

// Restore session
(function restore() {
  const u = Storage.getSession();
  if (u && users[u]) {
    current = users[u];
    UI.uiAfterLogin(u);
  } else {
    Storage.clearSession();
    UI.uiAfterLogout();
  }
})();

// UI update loop
setInterval(() => UI.updateUI(current), 800);
UI.updateUI(current);

// Expose dev helpers
window._sg = {
  getUsers: ()=> Storage.loadUsers(),
  getSession: ()=> Storage.getSession()
};