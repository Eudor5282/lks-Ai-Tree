// script/config.js

// ค่าคงที่สำหรับเกม
export const DAILY_LIMIT = 10;
export const QUIZ_REWARD = 1;

export const WATER_COST = 1; // เหรียญที่ใช้รดน้ำ
export const WATER_GAIN = 2.5; // การเติบโตที่ได้จากการรดน้ำ
export const FERT_COST = 2; // เหรียญที่ใช้ใส่ปุ๋ย
export const FERT_GAIN = 5; // การเติบโตที่ได้จากการใส่ปุ๋ย

// เกณฑ์การเติบโต: 5% → 15% → 25% → 40% → 60% → 80% (6 ขั้น)
export const GROWTH_THRESHOLDS = [5, 15, 25, 40, 60, 80];