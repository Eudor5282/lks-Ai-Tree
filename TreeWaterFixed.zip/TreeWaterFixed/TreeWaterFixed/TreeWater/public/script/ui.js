// ui.js
// script/ui.js
import { auth } from './firebase-config.js'; // Import auth จากไฟล์ Firebase
import { GROWTH_THRESHOLDS, DAILY_LIMIT, WATER_COST, FERT_COST } from './config.js'; // 💡 แก้ไข: Import ค่าคงที่เกมจาก config.js
// 💡 FIX: Import canAttemptQuiz จาก quiz.js เพื่อแก้ ReferenceError
import { canAttemptQuiz } from './quiz.js'; 

// Elements (ดึงมาจาก main.js เมื่อเริ่มต้น)
let elements = {};
// 💡 แก้ไข: เพิ่ม handleReset ในการประกาศ
let getCurrent, addLog, saveCurrent, onComplete, handleWater, handleFert, handleReset, handleSignup, handleLogin, handleLogout;

export function initUI(allElements, logicFunctions) {
  elements = allElements; // <-- FIX: Save elements globally here
  ({ 
    getCurrent, 
    addLog, 
    saveCurrent, 
    onComplete, 
    handleWater, 
    handleFert,
    handleReset, // 💡 NEW: Destructure handleReset
    handleSignup, 
    handleLogin, 
    handleLogout 
  } = logicFunctions);

  // Attach login/signup/logout handlers
  elements.signupBtn.addEventListener('click', handleSignup);
  elements.loginBtn.addEventListener('click', handleLogin);
  elements.logoutBtn.addEventListener('click', handleLogout);

  // Attach game control handlers
  elements.waterBtn.addEventListener('click', handleWater);
  elements.fertBtn.addEventListener('click', handleFert);
  elements.resetBtn.addEventListener('click', handleReset); // 💡 NEW: Attach reset handler
  
  // Note: elements.quizOpenBtn event listener ยังคงอยู่ที่ main.js เนื่องจากต้องใช้ async/await
}

// ------------------ UI Rendering ------------------

function getStageLabel(g) {
  if (g >= 100) return 'โตเต็มที่';
  if (g >= GROWTH_THRESHOLDS[5]) return '🌳 ต้นไม้ใหญ่';
  if (g >= GROWTH_THRESHOLDS[4]) return '🌲 ต้นไม้ขนาดกลาง';
  if (g >= GROWTH_THRESHOLDS[3]) return '🌱 ต้นกล้าแข็งแรง';
  if (g >= GROWTH_THRESHOLDS[2]) return '🌿 ต้นกล้าเล็ก';
  if (g >= GROWTH_THRESHOLDS[1]) return '🍃 งอกแล้ว';
  if (g >= GROWTH_THRESHOLDS[0]) return 'เมล็ดงอก';
  return '🌰 เมล็ด';
}

function renderTreeSVG(growth) {
  const stage = getStageLabel(growth);
  // ใช้ stage เพื่อเปลี่ยนรูป (สมมติว่ามีการกำหนด class/src ที่นี่)
  // โค้ดที่นี่ขาดไป แต่จะใช้ growth ในการอัพเดท
  
  // ตัวอย่างการเปลี่ยนรูป (ต้องมีรูปในโฟลเดอร์ img/tree-X.svg)
  let stageIdx;
  if (growth >= 100) stageIdx = 6;
  else if (growth >= GROWTH_THRESHOLDS[5]) stageIdx = 5;
  else if (growth >= GROWTH_THRESHOLDS[4]) stageIdx = 4;
  else if (growth >= GROWTH_THRESHOLDS[3]) stageIdx = 3;
  else if (growth >= GROWTH_THRESHOLDS[2]) stageIdx = 2;
  else if (growth >= GROWTH_THRESHOLDS[1]) stageIdx = 1;
  else if (growth >= GROWTH_THRESHOLDS[0]) stageIdx = 0;
  else stageIdx = -1;

  if (elements.treeStageEl) {
    if (stageIdx >= 0) {
        elements.treeStageEl.innerHTML = `<img src="img/tree-${stageIdx}.png" alt="${stage}" style="max-width:100%; height:auto;">`;
    } else {
        elements.treeStageEl.innerHTML = `<div>🌰</div>`; // เมล็ด
    }
  }
}

function renderLogs(current) {
  if (current && elements.logList) {
    elements.logList.innerHTML = current.logs.map(log => `<li>${log}</li>`).join('');
  } else if (elements.logList) {
    elements.logList.innerHTML = '<li>ยังไม่มีกิจกรรม</li>';
  }
}

function renderGameStatus(current) {
  const complete = current && (current.growth >= 100);

  if (complete) {
    elements.completeArea.innerHTML = `<div class="card complete-msg">✨ ยินดีด้วย! ต้นไม้ของคุณโตเต็มที่แล้ว! ✨</div>`;
    elements.gameStatusArea.innerHTML = '';
    // 💡 NEW: แสดงปุ่มรีเซ็ตเมื่อโตเต็มที่
    elements.resetBtn.style.display = 'block'; 
  } else {
    elements.completeArea.innerHTML = '';
    elements.gameStatusArea.innerHTML = '';
    // 💡 NEW: ซ่อนปุ่มรีเซ็ต
    elements.resetBtn.style.display = 'none'; 
  }
}

// อัพเดท UI ทั้งหมด
export function updateUI(current) {
  const growth = current ? current.growth : 0;
  const complete = (growth >= 100);

  elements.growthBar.style.width = growth + '%';
  elements.growthText.innerText = Math.round(growth) + '%';
  elements.coinDisplay.innerText = '🪙 ' + (current ? current.coins : 0);
  elements.attemptInfo.innerText = 'ตอบวันนี้: ' + (current ? current.quizCountToday : 0) + '/' + (current ? DAILY_LIMIT : 0);
  elements.stats.innerText = `Growth: ${Math.round(growth)}% · Coins: ${current ? current.coins : 0}`;
  elements.stageLabel.innerText = getStageLabel(growth);

  renderTreeSVG(growth);
  renderLogs(current);
  renderGameStatus(current);

  // Enable/disable buttons
  elements.waterBtn.disabled = !current || (current.coins < WATER_COST) || complete;
  elements.fertBtn.disabled = !current || (current.coins < FERT_COST) || complete;
  // 💡 FIX: ตรวจสอบ canAttemptQuiz สำหรับปุ่ม Quiz (ตอนนี้สามารถใช้งานได้แล้ว)
  elements.quizOpenBtn.disabled = !current || complete || !canAttemptQuiz(current);
}

// UI สำหรับสถานะ Login/Logout
export function uiAfterLogin(username) {
  elements.authRow.style.display = 'none';
  elements.logoutRow.style.display = 'flex';
  elements.userLabel.innerText = `ผู้ใช้: ${username}`;
}

export function uiAfterLogout() {
  elements.authRow.style.display = 'flex';
  elements.logoutRow.style.display = 'none';
  elements.userLabel.innerText = `ผู้ใช้: -`;
  // เคลียร์ Quiz Content
  elements.quizContent.innerHTML = ''; 
}