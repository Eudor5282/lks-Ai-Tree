// script/firebase-config.js
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';

// 🔥 TODO: แทนที่ค่าเหล่านี้ด้วย Firebase Config ของคุณ
const firebaseConfig = {
 apiKey: "AIzaSyCp8U7dwKvW1m4gCzRO54x0GJHuBpiQE4A",
  authDomain: "chatquiz-58a57.firebaseapp.com",
  projectId: "chatquiz-58a57",
  storageBucket: "chatquiz-58a57.firebasestorage.app",
  messagingSenderId: "494823000337",
  appId: "1:494823000337:web:94584d068993fd50a3a4b0",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

console.log('✅ Firebase initialized successfully!');