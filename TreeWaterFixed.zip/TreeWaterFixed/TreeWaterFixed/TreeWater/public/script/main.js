// main.js - Firebase Version
import * as Storage from './storage.js';
import * as UI from './ui.js';
import { GROWTH_THRESHOLDS, WATER_COST, WATER_GAIN, FERT_COST, FERT_GAIN, DAILY_LIMIT, QUIZ_REWARD } from './config.js'; // 💡 ต้อง Import จาก config.js
import { todayKey, canAttemptQuiz } from './quiz.js';
import { auth } from './firebase-config.js'; // 💡 ต้อง Import จาก firebase-config.js
/* ------------------ Global State ------------------ */
let current = null; // current user object (จาก Firestore)
let currentUid = null; // Firebase UID

// 💡 Global State สำหรับ AI Quiz
let aiQuizQueue = [];
let isGenerating = false;
let isStopped = false;
let aiTopic = '';
let aiCountTotal = 0;
let aiCountAnswered = 0;

/* ------------------ DOM Elements ------------------ */
const elements = {
  treeStageEl: document.getElementById('treeStage'),
  growthBar: document.getElementById('growthBar'),
  growthText: document.getElementById('growthText'),
  coinDisplay: document.getElementById('coinDisplay'),
  attemptInfo: document.getElementById('attemptInfo'),
  logList: document.getElementById('logList'),
  stats: document.getElementById('stats'),
  stageLabel: document.getElementById('stageLabel'),
  gameStatusArea: document.getElementById('gameStatusArea'),
  completeArea: document.getElementById('completeArea'),
  waterBtn: document.getElementById('waterBtn'),
  fertBtn: document.getElementById('fertBtn'),
  quizOpenBtn: document.getElementById('quizOpenBtn'),
  resetBtn: document.getElementById('resetBtn'),
  usernameInput: document.getElementById('usernameInput'),
  passwordInput: document.getElementById('passwordInput'),
  signupBtn: document.getElementById('signupBtn'),
  loginBtn: document.getElementById('loginBtn'),
  logoutBtn: document.getElementById('logoutBtn'),
  authRow: document.getElementById('authRow'),
  logoutRow: document.getElementById('logoutRow'),
  userLabel: document.getElementById('userLabel'),
  quizContent: document.getElementById('quizContent'),
  quizStopBtn: document.getElementById('quizStopBtn'),
  quizAiStatus: document.getElementById('quizAiStatus'),
};

/* ------------------ Core Logic Functions ------------------ */

function getCurrent() { return current; }

// 💾 บันทึกข้อมูลไป Firestore
async function saveCurrent() {
  if (!current || !currentUid) return;
  const result = await Storage.saveUserData(currentUid, current);
  if (!result.ok) {
    console.error('Failed to save user data:', result.msg);
  }
}

// 📝 เพิ่ม Log
function addLog(text) {
  if (!current) return;
  const ts = new Date().toLocaleString('th-TH');
  current.logs.unshift(`[${ts}] ${text}`);
  if (current.logs.length > 200) current.logs.length = 200;
}

// 🎉 เมื่อต้นไม้โตเต็มที่
function onComplete() {
  addLog('🎊 ต้นไม้โตเต็มที่ — จบเกม!');
  saveCurrent();
  UI.updateUI(current);
}

// 🔄 รีเซ็ตต้นไม้
function handleReset() {
  if (!current) return alert('กรุณา login ก่อน');
  
  if (current.growth >= 100) {
    current.growth = 0;
    addLog(`🌱 รีเซ็ตต้นไม้! เริ่มปลูกใหม่!`);
    saveCurrent();
    UI.updateUI(current);
  } else {
    alert('ต้นไม้ยังโตไม่เต็มที่ (ต้อง 100%)');
  }
}

/* ------------------ Auth Logic (Firebase) ------------------ */

async function handleSignup() {
  const email = elements.usernameInput.value.trim();
  const password = elements.passwordInput.value;
  
  if (!email || !password) {
    return alert('กรุณากรอกอีเมลและรหัสผ่าน');
  }
  
  elements.signupBtn.disabled = true;
  elements.signupBtn.innerText = 'กำลังสร้างบัญชี...';
  
  const result = await Storage.signupUser(email, password);
  
  if (result.ok) {
    // ข้อมูลจะถูกโหลดอัตโนมัติผ่าน onAuthChange
    elements.usernameInput.value = '';
    elements.passwordInput.value = '';
  } else {
    alert(result.msg);
  }
  
  elements.signupBtn.disabled = false;
  elements.signupBtn.innerText = 'Sign Up';
}

async function handleLogin() {
  const email = elements.usernameInput.value.trim();
  const password = elements.passwordInput.value;
  
  if (!email || !password) {
    return alert('กรุณากรอกอีเมลและรหัสผ่าน');
  }
  
  elements.loginBtn.disabled = true;
  elements.loginBtn.innerText = 'กำลังเข้าสู่ระบบ...';
  
  const result = await Storage.loginUser(email, password);
  
  if (result.ok) {
    // ข้อมูลจะถูกโหลดอัตโนมัติผ่าน onAuthChange
    elements.usernameInput.value = '';
    elements.passwordInput.value = '';
  } else {
    alert(result.msg);
  }
  
  elements.loginBtn.disabled = false;
  elements.loginBtn.innerText = 'Login';
}

async function handleLogout() {
  if (current) addLog('ออกจากระบบ');
  
  await Storage.logoutUser();
  
  current = null;
  currentUid = null;
  UI.uiAfterLogout();
  UI.updateUI(current);
}

/* ------------------ Game Control ------------------ */

function applyGrowth(delta, source) {
  if (!current || current.growth >= 100) return;
  const old = current.growth;
  current.growth = Math.min(100, current.growth + delta);
  saveCurrent();
  addLog(`${source}: +${delta}% (จาก ${Math.round(old)} → ${Math.round(current.growth)}%)`);
  UI.updateUI(current);
  if (current.growth >= 100) onComplete();
}

function handleWater() {
  if (!current) return alert('กรุณา login ก่อน');
  if (current.coins < WATER_COST) return alert('เหรียญไม่พอ');
  current.coins -= WATER_COST;
  applyGrowth(WATER_GAIN, '💧 รดน้ำ');
}

function handleFert() {
  if (!current) return alert('กรุณา login ก่อน');
  if (current.coins < FERT_COST) return alert('เหรียญไม่พอ');
  current.coins -= FERT_COST;
  applyGrowth(FERT_GAIN, '🌿 ปุ๋ย');
}

/* ------------------ AI Quiz Integration ------------------ */

async function startAIQuizGeneration() {
  if (!current) return alert('กรุณา login ก่อน');
  if (isGenerating) return;
  if (!canAttemptQuiz(current)) return alert(`คุณตอบครบ ${DAILY_LIMIT} ครั้งสำหรับวันนี้แล้ว 😊`);

  const topic = prompt("พิมพ์หัวข้อที่ต้องการให้ AI สร้างคำถาม:", aiTopic || "สิ่งแวดล้อม");
  if (!topic) return;
  
  const countInput = prompt("จำนวนคำถามที่ต้องการ (สูงสุด 10 ข้อ):", aiCountTotal > 0 ? aiCountTotal : 3);
  const count = parseInt(countInput) || 1;
  if (count <= 0 || count > 10) return alert('กรุณากรอกจำนวนคำถามระหว่าง 1 ถึง 10');

  aiTopic = topic;
  aiCountTotal = count;
  aiCountAnswered = 0;
  aiQuizQueue = [];
  isStopped = false;
  isGenerating = true;

  elements.quizOpenBtn.disabled = true;
  elements.quizStopBtn.style.display = 'inline-block';
  elements.quizAiStatus.style.display = 'inline-block';
  elements.quizContent.innerHTML = "⏳ กำลังสร้างคำถาม...";

  const nonce = `${Date.now()}-${Math.floor(Math.random()*1e9)}`;
  const apiUrl = `/api/quiz?cachebuster=${nonce}`;
  const payload = { 
    topic, 
    count,
    nonce: nonce,
    prompt_hint: `Generate ${count} UNRELATED and CONCEPTUALLY DIVERSE multiple-choice questions on "${topic}". Each question MUST cover a completely UNIQUE core fact or sub-topic.`
  };
  
  try {
    const res = await fetch(apiUrl, { 
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, max-age=0, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
      },
      body: JSON.stringify(payload)
    });
    
    const data = await res.json();
    const quizText = data.quiz || "❌ ไม่สามารถสร้างคำถามได้";
    
    if (!res.ok) {
      elements.quizContent.innerHTML = `<p style="color:red;">❌ API Error: ${data.quiz || 'ไม่ระบุ'}</p>`;
      return;
    }
    
    aiQuizQueue = parseAIQuiz(quizText);
    
    if (aiQuizQueue.length > 0 && aiQuizQueue.length !== aiCountTotal) {
      aiCountTotal = aiQuizQueue.length;
      addLog(`ปรับจำนวนคำถามเป็น ${aiCountTotal} เนื่องจาก AI ตอบมาไม่ครบ`);
    }

    if (aiQuizQueue.length === 0) {
      elements.quizContent.innerHTML = `<p style="color:red;">❌ Parsing Failed</p><pre style="white-space:pre-wrap; max-height:100px; overflow-y:auto;">${escapeHtml(quizText)}</pre>`;
      return; 
    }

  } catch (err) {
    elements.quizContent.innerHTML = `<p style="color:red;">❌ Connection Error: ${escapeHtml(err.message)}</p>`;
  } finally {
    isGenerating = false;
    
    if (!isStopped) {
      if (aiQuizQueue.length > 0) {
        nextAIQuestion();
      } else {
        resetAIQuizState();
      }
    } else {
      resetAIQuizState();
    }
  }
}

function nextAIQuestion() {
  if (isStopped || aiQuizQueue.length === 0) {
    resetAIQuizState();
    return;
  }

  if (!canAttemptQuiz(current)) {
    alert(`คุณตอบครบ ${DAILY_LIMIT} ครั้งสำหรับวันนี้แล้ว 😊`);
    resetAIQuizState();
    return;
  }

  const qObj = aiQuizQueue.shift();
  aiCountAnswered++;
  elements.quizAiStatus.innerText = `หัวข้อ: ${aiTopic} | คำถามที่: ${aiCountAnswered}/${aiCountTotal}`;
  showAIQuestion(qObj, current, elements.quizContent);
}

function parseAIQuiz(text) {
  const quizItems = text.split('---QUIZ-ITEM---').map(s => s.trim()).filter(s => s);
  const parsedQuizzes = [];

  quizItems.forEach((item) => {
    try {
      const lines = item.split('\n').map(l=>l.trim()).filter(l=>l);
      
      const questionLine = lines.find(l => l.match(/^(?:\d+\.\s*)?(?:คำถาม|Q|คำถามที่ \d+)\s*:/i));
      if (!questionLine) return;

      const choices = lines.filter(l => /^[a-cA-C]\./.test(l)).map(l => l.replace(/^[a-cA-C]\./, '').trim()); 
      const answerLine = lines.find(l => l.match(/^คำตอบที่ถูก\s*:/));
      
      if (choices.length !== 3 || !answerLine) return;
      
      const qMatch = questionLine.match(/^(?:\d+\.\s*)?(?:คำถาม|Q|คำถามที่ \d+)\s*:\s*(.*)/i);
      const question = qMatch ? qMatch[1].trim() : questionLine.trim();

      const answerMatch = answerLine.match(/คำตอบที่ถูก:\s*([A-C])/i);
      if (!answerMatch) return; 
      
      const answerChar = answerMatch[1].toUpperCase();
      const answerIndex = ['A','B','C'].indexOf(answerChar);
      
      if (answerIndex === -1) return; 
      
      parsedQuizzes.push({ question, choices, answerIndex });
    } catch(e) { 
      console.error("parseAIQuiz error:", e); 
    }
  });

  return parsedQuizzes;
}

function showAIQuestion(qObj, current, container) {
  container.innerHTML = '';
  
  const elQ = document.createElement('div');
  elQ.innerHTML = `<div style="font-weight:700">${escapeHtml(qObj.question)}</div><div class="muted" style="margin-top:6px">เลือกคำตอบ</div>`;

  const choicesWrap = document.createElement('div');
  choicesWrap.className = 'choices';

  if (!qObj.choices || !Array.isArray(qObj.choices)) {
    container.innerHTML = `<p style="color:red;">❌ คำถามนี้ไม่มีตัวเลือกที่สมบูรณ์</p>`;
    return;
  }

  qObj.choices.forEach((c, i) => {
    const btn = document.createElement('button');
    btn.className = 'choice-btn';
    btn.innerText = c;
    btn.addEventListener('click', () => handleAIAnswer(btn, i === qObj.answerIndex, qObj, current, container));
    choicesWrap.appendChild(btn);
  });

  container.appendChild(elQ);
  container.appendChild(choicesWrap);
}

function handleAIAnswer(btn, correct, qObj, current, container) {
  const btns = container.querySelectorAll('.choice-btn');
  btns.forEach(b => b.disabled = true);

  current.quizCountToday = (current.quizCountToday || 0) + 1;
  current.lastQuizDate = todayKey(); 

  if (correct) {
    current.coins = (current.coins || 0) + QUIZ_REWARD;
    addLog(`✅ ตอบ AI Quiz ถูก (Q${aiCountAnswered}): +${QUIZ_REWARD} coin`);
    btn.classList.add('correct');
  } else {
    addLog(`❌ ตอบ AI Quiz ผิด (Q${aiCountAnswered})`);
    btn.classList.add('wrong');
    if (btns[qObj.answerIndex]) {
      btns[qObj.answerIndex].classList.add('correct');
    }
  }

  saveCurrent();
  UI.updateUI(current); 
  
  setTimeout(() => {
    if (isStopped) {
      resetAIQuizState();
    } else if (aiQuizQueue.length === 0) { 
      alert(`🎉 ตอบครบ ${aiCountTotal} ข้อแล้ว!`); 
      resetAIQuizState();
    } else {
      nextAIQuestion();
    }
  }, 1500);
}

function stopAIQuizGeneration() {
  isStopped = true;
  resetAIQuizState();
}

function resetAIQuizState() {
  aiQuizQueue = [];
  isGenerating = false;
  isStopped = false;
  aiCountAnswered = 0;
  aiCountTotal = 0;

  elements.quizStopBtn.style.display = 'none';
  elements.quizAiStatus.style.display = 'none';
  elements.quizAiStatus.innerText = '';
  elements.quizContent.innerHTML = `<div class="muted">กด "ตอบคำถาม" เพื่อเริ่ม</div>`;
  
  UI.updateUI(current);
  if (current) saveCurrent();
}

function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[c]);
}

/* ------------------ Initialization ------------------ */

elements.quizOpenBtn.addEventListener('click', startAIQuizGeneration);
elements.quizStopBtn.addEventListener('click', stopAIQuizGeneration);

UI.initUI(elements, { 
  getCurrent, 
  addLog, 
  saveCurrent, 
  onComplete,
  handleWater, 
  handleFert,
  handleReset,
  handleSignup, 
  handleLogin, 
  handleLogout 
});

// 🔥 Firebase Auth State Listener
Storage.onAuthChange(async (user) => {
  if (user) {
    // ผู้ใช้ Login แล้ว
    console.log('✅ User logged in:', user.email);
    currentUid = user.uid;
    
    // ดึงข้อมูลจาก Firestore
    const result = await Storage.getUserData(user.uid);
    if (result.ok) {
      current = result.data;
      current.email = user.email; // เพิ่ม email เข้าไป
      UI.uiAfterLogin(user.email);
      UI.updateUI(current);
    } else {
      alert('ไม่สามารถโหลดข้อมูลได้');
    }
  } else {
    // ผู้ใช้ Logout
    console.log('❌ User logged out');
    current = null;
    currentUid = null;
    UI.uiAfterLogout();
    UI.updateUI(current);
  }
});

// UI update loop
setInterval(() => UI.updateUI(current), 800);

// Dev helpers
window._sg = {
  getCurrentUser: () => auth.currentUser,
  getCurrentData: () => current,
  forceLogout: () => handleLogout()
};