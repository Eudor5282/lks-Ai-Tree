// script/storage.js - Firebase Version
import { auth, db } from './firebase-config.js';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc,
  serverTimestamp 
} from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';

/* ------------------ Firebase Auth Functions ------------------ */

// 📝 สร้างบัญชีใหม่ (Sign Up)
export async function signupUser(email, password) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // สร้างข้อมูลเริ่มต้นใน Firestore
    await setDoc(doc(db, 'users', user.uid), {
      email: user.email,
      growth: 0,
      coins: 10, // เริ่มต้น 10 เหรียญ
      lastQuizDate: null,
      quizCountToday: 0,
      logs: [],
      createdAt: serverTimestamp(),
      lastUpdated: serverTimestamp()
    });
    
    return { ok: true, user };
  } catch (error) {
    console.error('Signup error:', error);
    return { ok: false, msg: getErrorMessage(error.code) };
  }
}

// 🔐 เข้าสู่ระบบ (Login)
export async function loginUser(email, password) {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { ok: true, user: userCredential.user };
  } catch (error) {
    console.error('Login error:', error);
    return { ok: false, msg: getErrorMessage(error.code) };
  }
}

// 🚪 ออกจากระบบ (Logout)
export async function logoutUser() {
  try {
    await signOut(auth);
    return { ok: true };
  } catch (error) {
    console.error('Logout error:', error);
    return { ok: false, msg: 'เกิดข้อผิดพลาดในการออกจากระบบ' };
  }
}

// 👤 ดึงข้อมูลผู้ใช้จาก Firestore
export async function getUserData(uid) {
  try {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return { ok: true, data: docSnap.data() };
    } else {
      // ถ้าไม่มีข้อมูล ให้สร้างใหม่
      const defaultData = {
        email: auth.currentUser?.email || '',
        growth: 0,
        coins: 10,
        lastQuizDate: null,
        quizCountToday: 0,
        logs: [],
        createdAt: serverTimestamp(),
        lastUpdated: serverTimestamp()
      };
      await setDoc(docRef, defaultData);
      return { ok: true, data: defaultData };
    }
  } catch (error) {
    console.error('Get user data error:', error);
    return { ok: false, msg: 'ไม่สามารถดึงข้อมูลได้' };
  }
}

// 💾 บันทึกข้อมูลผู้ใช้ไป Firestore
export async function saveUserData(uid, data) {
  try {
    const docRef = doc(db, 'users', uid);
    await updateDoc(docRef, {
      ...data,
      lastUpdated: serverTimestamp()
    });
    return { ok: true };
  } catch (error) {
    console.error('Save user data error:', error);
    return { ok: false, msg: 'ไม่สามารถบันทึกข้อมูลได้' };
  }
}

// 🎧 ฟังการเปลี่ยนแปลงสถานะการเข้าสู่ระบบ
export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}

// ❌ แปลง Error Code เป็นข้อความภาษาไทย
function getErrorMessage(errorCode) {
  const errors = {
    'auth/email-already-in-use': 'อีเมลนี้ถูกใช้งานแล้ว',
    'auth/invalid-email': 'รูปแบบอีเมลไม่ถูกต้อง',
    'auth/weak-password': 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร',
    'auth/user-not-found': 'ไม่พบผู้ใช้นี้',
    'auth/wrong-password': 'รหัสผ่านไม่ถูกต้อง',
    'auth/too-many-requests': 'มีการพยายามเข้าสู่ระบบมากเกินไป กรุณารอสักครู่',
    'auth/network-request-failed': 'เกิดข้อผิดพลาดในการเชื่อมต่อ'
  };
  return errors[errorCode] || 'เกิดข้อผิดพลาด: ' + errorCode;
}

/* ------------------ Legacy Functions (ถ้ามีโค้ดเก่าเรียกใช้) ------------------ */

// ⚠️ ฟังก์ชันเหล่านี้จะไม่ทำงานแล้ว (เพราะใช้ Firebase แทน)
export function loadUsers() {
  console.warn('loadUsers() is deprecated - using Firebase');
  return {};
}

export function saveUsers() {
  console.warn('saveUsers() is deprecated - using Firebase');
}

export function setSession() {
  console.warn('setSession() is deprecated - Firebase handles sessions');
}

export function getSession() {
  console.warn('getSession() is deprecated - Firebase handles sessions');
  return null;
}

export function clearSession() {
  console.warn('clearSession() is deprecated - use logoutUser()');
}

export function createUserObj() {
  console.warn('createUserObj() is deprecated - using Firestore');
  return {};
}