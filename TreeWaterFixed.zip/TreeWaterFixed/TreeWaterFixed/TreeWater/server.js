// server.js
import express from "express";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// serve static from public (adjust if your static lives elsewhere)
app.use(express.static(path.join(__dirname, "public")));

const OPENROUTER_KEY = process.env.OPENROUTER_KEY || process.env.OPENROUTER_API_KEY || "";

/** Build prompt for normal or forceJson mode */
function buildPrompt(topic, count, forceJson = false) {
  if (forceJson) {
    return `
You are a strict Quiz Generator.
Return ONLY a single valid JSON array (no explanation, no extra text). Example:
[
  {"question":"...","choices":["optA","optB","optC"],"answer":"A"},
  ...
]
Make exactly ${count} items in the array. Each "choices" array must contain exactly 3 strings.
"answer" must be one of "A","B","C".
`;
  }

  return `
คุณคือ AI ที่สร้างแบบทดสอบ (Quiz Generator)
จงสร้างคำถามหัวข้อ "${topic}" จำนวน ${count} ข้อ **ต้องครบทุกข้อ**
รูปแบบการตอบ (ตัวอย่าง) ต้องเป็นแบบนี้เท่านั้น:
---QUIZ-ITEM---
คำถามที่ 1: [คำถาม]
A. [ตัวเลือก 1]
B. [ตัวเลือก 2]
C. [ตัวเลือก 3]
คำตอบที่ถูก: [A/B/C]
---QUIZ-ITEM---
ห้ามใส่ข้อความเพิ่มเติม ห้ามอธิบายเพิ่มเติม ห้ามแทรก JSON หรือ markdown
`;
}

app.post("/api/quiz", async (req, res) => {
  const topic = req.body.topic || "ทั่วไป";
  const count = Math.max(1, parseInt(req.body.count) || 1);
  const forceJson = !!req.body.forceJson;

  const userPrompt = buildPrompt(topic, count, forceJson);

  try {
    // Use system message to make model strict & temperature low
    const bodyPayload = {
      model: "tngtech/deepseek-r1t2-chimera:free",
      messages: [
        {
          role: "system",
          content: `You are a strict Quiz Generator. Output either a JSON array only (preferred when forceJson) or the exact ---QUIZ-ITEM--- text format. Do not add extra commentary.`
        },
        { role: "user", content: userPrompt }
      ],
      temperature: 0,
      max_tokens: Math.min(2000, 250 * count)
    };

    const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENROUTER_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(bodyPayload),
    });

    const data = await resp.json();

    if (!resp.ok) {
      console.error("OpenRouter error:", data);
      const errMsg = data.error?.message || JSON.stringify(data).slice(0, 200);
      return res.status(500).json({ error: true, message: `OpenRouter error: ${errMsg}`, raw: data });
    }

    const quizRaw = data.choices?.[0]?.message?.content?.trim() || "";
    console.log("🟢 AI raw reply >>>\n", quizRaw);
    // try to detect JSON array anywhere in the raw output
   // try to detect JSON array anywhere in the raw output
const jsonMatch = quizRaw.match(/\[ *\{[\s\S]*\}\s*]/m);
if (jsonMatch) {
  try {
    const parsed = JSON.parse(jsonMatch[0]); // ✅ ต้องอยู่ตรงนี้ก่อน
    if (Array.isArray(parsed)) {
      // ✅ ส่งคืนแบบที่ main.js รองรับ
      return res.json({ quiz: quizRaw, quizJson: parsed });
    }
  } catch (e) {
    console.warn("JSON detected but parse failed:", e.message);
  }
}


    // Otherwise return raw text (text-format mode)
    res.json({ quiz: quizRaw });
  } catch (err) {
    console.error("Server error:", err);
    res.status(500).json({ error: true, message: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("🚀 Server is running at:");
  console.log("\x1b[36m%s\x1b[0m", `👉 http://localhost:${PORT}`);
});
