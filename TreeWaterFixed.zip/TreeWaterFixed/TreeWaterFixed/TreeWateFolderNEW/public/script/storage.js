import { LS_USERS, LS_SESSION } from './config.js';

/* ------------------ util: storage & users ------------------ */

// โหลดข้อมูลผู้ใช้ทั้งหมดจาก LocalStorage
export function loadUsers() {
  try {
    return JSON.parse(localStorage.getItem(LS_USERS) || '{}');
  } catch (e) {
    console.error("Error loading users:", e);
    return {};
  }
}

// บันทึกข้อมูลผู้ใช้ทั้งหมดไป LocalStorage
export function saveUsers(obj) {
  localStorage.setItem(LS_USERS, JSON.stringify(obj));
}

// บันทึก Session (Username ที่ Login อยู่)
export function setSession(username) {
  localStorage.setItem(LS_SESSION, username);
}

// โหลด Session (Username ที่ Login อยู่)
export function getSession() {
  return localStorage.getItem(LS_SESSION);
}

// ล้าง Session
export function clearSession() {
  localStorage.removeItem(LS_SESSION);
}

// สร้าง Object ผู้ใช้เริ่มต้น
export function createUserObj(username, password) {
  // password stored base64 just for demo (not secure)
  return {
    username,
    password: btoa(password || ''),
    growth: 0,
    coins: 0, // <-- FIX: ผู้ใช้ใหม่เริ่มต้นด้วย 10 เหรียญ
    lastQuizDate: null, // "YYYY-MM-DD"
    quizCountToday: 0,
    logs: []
  };
}