import { QUESTIONS, DAILY_LIMIT, QUIZ_REWARD } from './config.js';
import { updateUI } from './ui.js';

// Elements (ดึงมาจาก main.js เมื่อเริ่มต้น)
let quizContent, nextQBtn; // ลบ quizOpenBtn ออก

export function initQuiz(elements) {
  quizContent = elements.quizContent;
  nextQBtn = elements.nextQBtn;
  // ลบ: quizOpenBtn = elements.quizOpenBtn;

  // ผูก Listener กับ nextQBtn เท่านั้น (สำหรับ Static Quiz ที่ซ่อนอยู่)
  if (nextQBtn) { 
    nextQBtn.addEventListener('click', () => {
      startQuiz(elements.getCurrent, elements.addLog, elements.saveCurrent);
    });
  }
  
  // ลบ: ผูก Listener ซ้ำซ้อนของ quizOpenBtn ออก 
  /*
  elements.quizOpenBtn.addEventListener('click', () => {
    startQuiz(elements.getCurrent, elements.addLog, elements.saveCurrent);
  });
  */
}

export function todayKey() { // Export todayKey เพื่อให้ main.js ใช้ได้
  const d = new Date();
  // ใช้ .padStart เพื่อให้รูปแบบเป็น YYYY-MM-DD
  const year = d.getFullYear();
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const day = d.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// รีเซ็ตการนับ Quiz หากเป็นวันใหม่
function resetQuizIfNewDay(current) {
  if (!current) return;
  const today = todayKey(); 
  if (current.lastQuizDate !== today) {
    current.lastQuizDate = today;
    current.quizCountToday = 0;
    return true; // มีการรีเซ็ต
  }
  return false;
}

// ตรวจสอบว่าสามารถตอบ Quiz ได้หรือไม่
export function canAttemptQuiz(current) {
  if (!current) return false;
  // ตรวจสอบและรีเซ็ตวันก่อน
  resetQuizIfNewDay(current); 
  return current.quizCountToday < DAILY_LIMIT;
}

// เริ่มต้น Quiz (เปิดคำถามใหม่ - Static Quiz)
export function startQuiz(getCurrent, addLog, saveCurrent) {
  const current = getCurrent();
  if (!current) return alert('กรุณา login ก่อน');
  
  if (!canAttemptQuiz(current)) return alert(`คุณตอบครบ ${DAILY_LIMIT} ครั้งสำหรับวันนี้แล้ว 😊`);
  
  const q = randomQuestion();
  showQuestion(q, getCurrent, addLog, saveCurrent);
}

// สุ่มคำถามและสลับตัวเลือก
function randomQuestion() {
  const idx = Math.floor(Math.random() * QUESTIONS.length);
  const q = JSON.parse(JSON.stringify(QUESTIONS[idx])); // clone question

  const correctIndex = q.a;
  const choices = q.choices.map((c, i) => ({ c, i }));
  // shuffle choices (Fisher-Yates)
  for (let i = choices.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [choices[i], choices[j]] = [choices[j], choices[i]];
  }

  const newCorrect = choices.findIndex(x => x.i === correctIndex);
  q.choices = choices.map(x => x.c);
  q.a = newCorrect;
  return q;
}

// แสดงคำถามใน UI
function showQuestion(q, getCurrent, addLog, saveCurrent) {
  quizContent.innerHTML = '';
  //nextQBtn.style.display = 'none';

  const elQ = document.createElement('div');
  elQ.innerHTML = `<div style="font-weight:700">${q.q}</div><div class="muted" style="margin-top:6px">เลือกคำตอบ</div>`;
  const choicesWrap = document.createElement('div');
  choicesWrap.className = 'choices';

  q.choices.forEach((c, i) => {
    const btn = document.createElement('button');
    btn.className = 'choice-btn';
    btn.innerText = c;
    btn.addEventListener('click', () => {
      handleAnswer(btn, i === q.a, q, getCurrent, addLog, saveCurrent);
    });
    choicesWrap.appendChild(btn);
  });
  quizContent.appendChild(elQ);
  quizContent.appendChild(choicesWrap);
}

// จัดการเมื่อผู้ใช้เลือกคำตอบ
function handleAnswer(btn, correct, q, getCurrent, addLog, saveCurrent) {
  const current = getCurrent();
  // disable all choices
  const btns = quizContent.querySelectorAll('.choice-btn');
  btns.forEach(b => b.disabled = true);

  // Update user stats
  current.quizCountToday = (current.quizCountToday || 0) + 1;
  current.lastQuizDate = todayKey(); // ใช้ todayKey()

  if (correct) {
    current.coins = (current.coins || 0) + QUIZ_REWARD;
    addLog(`ตอบคำถามถูก: +${QUIZ_REWARD} coin`);
    btn.classList.add('correct');
  } else {
    addLog('ตอบคำถามผิด');
    btn.classList.add('wrong');
    // Highlight correct one
    btns.forEach((b, idx) => {
      if (idx === q.a) b.classList.add('correct');
    });
  }

  saveCurrent();
  updateUI(current); // อัพเดท UI หลังตอบ
  //nextQBtn.style.display = 'inline-block';
}